<?php

namespace App\Verification;

class Prix{
 
}