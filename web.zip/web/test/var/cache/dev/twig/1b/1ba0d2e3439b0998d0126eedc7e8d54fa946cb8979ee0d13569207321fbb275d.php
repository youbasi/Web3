<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/index.html.twig */
class __TwigTemplate_c4781946ba6472096f0ea592ad471b20944aaad1e25bf938158ddb6899cea0f1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "home/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <center><h1> bienvenue à l'acceuil </h1>
    </br>
    </br>
    </br>
    <table>
        <tr>
        <th scoope=\"col\">
            
            <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/anchors\"  style=\"width:550px ;height:90px\" type=\"button\"> Enchéres </a>
            </br>
            </br>
            ";
        // line 14
        if ( !twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 14, $this->source); })()), "user", [], "any", false, false, false, 14)) {
            // line 15
            echo "                <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/inscription\" style=\"width:550px ;height:90px\" type=\"button\"> Inscription </a>
            ";
        } else {
            // line 17
            echo "                <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/historique\" style=\"width:550px ;height:90px\" type=\"button\"> Historique d'enchéres </a>
            ";
        }
        // line 18
        echo "    
            </br>
            </br>
            <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/packJetons\" style=\"width:550px ;height:90px\" type=\"button\">Packs jetons</a>
            </br>
            </br>
            <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/help\" style=\"width:550px ;height:90px\" type=\"button\">Comment ça marche? </a>
            </br>
        </th>
        <th scoope=\"col\">
            <h1>&nbsp; &nbsp;&nbsp;</h1>
        </th>
        <th scoope=\"col\">
            <img src=\"https://www.nationspresse.info/wp-content/uploads/2018/11/comment-se-deroulent-les-ventes-aux-encheres.jpg\" height= \"500\" width=\"450\">
        </th>
        </tr>    
    </table>
        
    </center> 
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 18,  87 => 17,  83 => 15,  81 => 14,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block body %}
    <center><h1> bienvenue à l'acceuil </h1>
    </br>
    </br>
    </br>
    <table>
        <tr>
        <th scoope=\"col\">
            
            <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/anchors\"  style=\"width:550px ;height:90px\" type=\"button\"> Enchéres </a>
            </br>
            </br>
            {% if not app.user  %}
                <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/inscription\" style=\"width:550px ;height:90px\" type=\"button\"> Inscription </a>
            {% else %}
                <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/historique\" style=\"width:550px ;height:90px\" type=\"button\"> Historique d'enchéres </a>
            {% endif %}    
            </br>
            </br>
            <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/packJetons\" style=\"width:550px ;height:90px\" type=\"button\">Packs jetons</a>
            </br>
            </br>
            <a class=\"btn btn-primary btn-lg btn-block\"; href=\"/help\" style=\"width:550px ;height:90px\" type=\"button\">Comment ça marche? </a>
            </br>
        </th>
        <th scoope=\"col\">
            <h1>&nbsp; &nbsp;&nbsp;</h1>
        </th>
        <th scoope=\"col\">
            <img src=\"https://www.nationspresse.info/wp-content/uploads/2018/11/comment-se-deroulent-les-ventes-aux-encheres.jpg\" height= \"500\" width=\"450\">
        </th>
        </tr>    
    </table>
        
    </center> 
{% endblock %}
", "home/index.html.twig", "C:\\Users\\33603\\Desktop\\web\\test\\templates\\home\\index.html.twig");
    }
}
