<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/anchors.html.twig */
class __TwigTemplate_151d7065e59b840b9ea4467314a47ccc09b33c34414fe0eb76ab3b876541eebc extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/anchors.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/anchors.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "home/anchors.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div id=\"carouselExampleIndicators\" class=\"carousel slide\" data-ride=\"carousel\">
  <ol class=\"carousel-indicators\">
    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"0\" class=\"active\"></li>
    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"1\"></li>
    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"2\"></li>
  </ol>
  <div class=\"carousel-inner\">
    <div class=\"carousel-item active\">
      <img class=\"d-block w-100\" src=\"https://i.ytimg.com/vi/DHR5OrIYzpQ/maxresdefault.jpg\" alt=\"First slide\">
    </div>
    <div class=\"carousel-item\">
      <img class=\"d-block w-100\" src=\"https://a57.foxnews.com/a57.foxnews.com/static.foxnews.com/foxnews.com/content/uploads/2019/02/640/320/1862/1048/f83.jpg?ve=1&tl=1?ve=1&tl=1\" alt=\"Second slide\">
    </div>
    <div class=\"carousel-item\">
      <img class=\"d-block w-100\" src=\"https://www.maserati.com/mediaObject/sites/international/News/2017/Ghibli-Nerissimo/Maserati-at-NYIAS-2017---Ghibli-Nerissimo-edition---studio-w-(1)/original/Maserati+at+NYIAS+2017+-+Ghibli+Nerissimo+edition+-+studio+w+%281%29.jpg\" alt=\"Third slide\">
    </div>
  </div>
  <a class=\"carousel-control-prev\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"prev\">
    <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Previous</span>
  </a>
  <a class=\"carousel-control-next\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"next\">
    <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Next</span>
  </a>
</div>

<table class=\"table table-hover\">
    <thead>
        <tr class=\"table-active\">
        <th scope=\"col\">num</th>
        <th scope=\"col\">image</th>
        <th scope=\"col\" width=\"250\">Déscription</th>
        <th scope=\"col\">Prix </th>
        <th scope=\"col\">Date de Fin </th>
        <th scope=\"col\">placer une enchére </th>
        </tr>
    </thead>
    <tbody>
    ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["anchors"]) || array_key_exists("anchors", $context) ? $context["anchors"] : (function () { throw new RuntimeError('Variable "anchors" does not exist.', 43, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["anchor"]) {
            echo "   
        <tr>
            <th scope=\"row\">";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["anchor"], "id", [], "any", false, false, false, 45), "html", null, true);
            echo "</th>
                <td><table>
                    <tr>
                        <th><img src=\"/images/produits/";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["anchor"], "image", [], "any", false, false, false, 48), "html", null, true);
            echo "\" style=\"width:8rem; height: 8rem;\" /></th>
                    </tr>
                    <tr>
                        <th><p5>";
            // line 51
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["anchor"], "reference", [], "any", false, false, false, 51), "html", null, true);
            echo "</p5></th>
                    </tr>
                </table></td>
                <td><table>
                    <tr>
                        <th>";
            // line 56
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["anchor"], "descriptif", [], "any", false, false, false, 56), "html", null, true);
            echo "</th>
                    </tr>
                    <tr>
                        
                        <th> ";
            // line 60
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["anchor"], "createdAt", [], "any", false, false, false, 60), "d / m / Y , H : m"), "html", null, true);
            echo "<th>
                        
                    </tr>
                    
                </table></td>
                <td>";
            // line 65
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["anchor"], "prix", [], "any", false, false, false, 65), "html", null, true);
            echo " €</td>
                <td><table>
                    <tr>
                        <span class=\"title5 countdown \">
                                <div id=\"affiche\">Temps avant fin des enchères.</div>
                                    <script type=\"text/javascript\">
                                        var finTemps = produit.dateFin ; // < ?php echo \$donnees['finEnchere']; ? >
                                        var timestampActuel = <?php echo time(); ?>; // donne le timestamp actuel
                                        var duree = finTemps - timestampActuel; // durée = temps total - temps actuel
                                        var dureeHeure, dureeMinute, dureeSeconde; // initialise variable, pour qu'elles ne soient pas global
                                        var div = document.getElementById(\"affiche\"); // récupère la div affiche
                                
                                        // fait un interval régulier de 1s
                                        var timer = setInterval(function(){
                                                                
                                        // boucle tant que la durée est supérieur à 0
                                            if(duree>0)
                                            {
                                                dureeHeure = parseInt(duree/3600);
                                                dureeMinute = parseInt((duree-(dureeHeure*3600))/60);
                                                dureeSeconde = duree-((dureeHeure*3600)+(dureeMinute*60));
                                                var old_contenu = div.firstChild; // récup le premier enfant (le texte)
                                                div.removeChild(old_contenu); // supprime l'ancien contenu
                                                var texte = document.createTextNode(dureeHeure+\":\"+dureeMinute+\":\"+dureeSeconde); // crée un node texte valeur de la durée
                                                div.appendChild(texte); // affiche le node
                                                
                                                duree -= 1; // diminue la durée de l'enchère
                                            }
                                            // si l'enchère est finis
                                            else
                                            {
                                                var old_contenu = div.firstChild;
                                                div.removeChild(old_contenu); // supprime le contenu
                                                var texte = document.createTextNode('Enchère finis !'); // affiche message de fin, voir une alert
                                                div.appendChild(texte);
                                                clearInterval(timer); // interrompt la boucle de setInterval
                                            }
                                    }, 1000); // 1000ms
                                </script>                        
                        </span>
                    </tr>  
                    <tr>
                        <th>
                        ";
            // line 108
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["produits"]) || array_key_exists("produits", $context) ? $context["produits"] : (function () { throw new RuntimeError('Variable "produits" does not exist.', 108, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["produit"]) {
                // line 109
                echo "                            ";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["produit"], "dateFin", [], "any", false, false, false, 109), "d / m / Y , H : m"), "html", null, true);
                echo "
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['produit'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 111
            echo "                        </th>
                    </tr>   
                </table></td>
                    
                ";
            // line 115
            if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 115, $this->source); })()), "user", [], "any", false, false, false, 115)) {
                // line 116
                echo "                <td><table>
                    <tr>
                        <td><input class=\"form-control\" id=\"inputEncheres\" placeholder=\"Placez votre enchére\" label=\"prix\" style=\"width:150px\"></td>
                            ";
                // line 119
                $this->displayBlock('javascript', $context, $blocks);
                // line 131
                echo "                        <td><button type=\"submit\" onclick=\"readInput();\"class=\"btn btn-secondary\">enchérir</button>
                        </td>
                    </tr></table>
                    <table>
                    <tr>
                        <td><input class=\"form-control\" id=\"inputDefault\" placeholder=\"de\" style=\"width:70px\"></td>
                        <td><input class=\"form-control\" id=\"inputDefault\" placeholder=\"à\"  style=\"width:70px\"></td>
                        <td><button type=\"submit\" class=\"btn btn-secondary\">enchérir</button></td>
                    </tr>
                </table></td>
                ";
            } else {
                // line 142
                echo "                    <td><a type=\"submit\" class=\"btn btn-secondary\" href=\"/inscription\">inscrivez vous pour enchérir</a></td>
                ";
            }
            // line 144
            echo "        </tr>            
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['anchor'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 146
        echo "    </tbody>
</table>    
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 119
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        // line 120
        echo "                                <script type=\"text/javascript\">
                                    function readInput(){
                                        //console.log(\"bonsoir\");   //test function 
                                        var encheres = new Array();
                                        var saisie= document.getElementById('inputEncheres').value;
                                        var inputs= encheres.push(saisie); // stocker toutes les inputs dans encheres (fait)
                                    }
                                    
                                
                                </script>
                            ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "home/anchors.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  312 => 120,  302 => 119,  290 => 146,  275 => 144,  271 => 142,  258 => 131,  256 => 119,  251 => 116,  249 => 115,  243 => 111,  234 => 109,  230 => 108,  184 => 65,  176 => 60,  169 => 56,  161 => 51,  155 => 48,  149 => 45,  129 => 43,  88 => 4,  78 => 3,  60 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}{% endblock %}
{% block body %}
    <div id=\"carouselExampleIndicators\" class=\"carousel slide\" data-ride=\"carousel\">
  <ol class=\"carousel-indicators\">
    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"0\" class=\"active\"></li>
    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"1\"></li>
    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"2\"></li>
  </ol>
  <div class=\"carousel-inner\">
    <div class=\"carousel-item active\">
      <img class=\"d-block w-100\" src=\"https://i.ytimg.com/vi/DHR5OrIYzpQ/maxresdefault.jpg\" alt=\"First slide\">
    </div>
    <div class=\"carousel-item\">
      <img class=\"d-block w-100\" src=\"https://a57.foxnews.com/a57.foxnews.com/static.foxnews.com/foxnews.com/content/uploads/2019/02/640/320/1862/1048/f83.jpg?ve=1&tl=1?ve=1&tl=1\" alt=\"Second slide\">
    </div>
    <div class=\"carousel-item\">
      <img class=\"d-block w-100\" src=\"https://www.maserati.com/mediaObject/sites/international/News/2017/Ghibli-Nerissimo/Maserati-at-NYIAS-2017---Ghibli-Nerissimo-edition---studio-w-(1)/original/Maserati+at+NYIAS+2017+-+Ghibli+Nerissimo+edition+-+studio+w+%281%29.jpg\" alt=\"Third slide\">
    </div>
  </div>
  <a class=\"carousel-control-prev\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"prev\">
    <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Previous</span>
  </a>
  <a class=\"carousel-control-next\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"next\">
    <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Next</span>
  </a>
</div>

<table class=\"table table-hover\">
    <thead>
        <tr class=\"table-active\">
        <th scope=\"col\">num</th>
        <th scope=\"col\">image</th>
        <th scope=\"col\" width=\"250\">Déscription</th>
        <th scope=\"col\">Prix </th>
        <th scope=\"col\">Date de Fin </th>
        <th scope=\"col\">placer une enchére </th>
        </tr>
    </thead>
    <tbody>
    {% for anchor in anchors %}   
        <tr>
            <th scope=\"row\">{{anchor.id}}</th>
                <td><table>
                    <tr>
                        <th><img src=\"/images/produits/{{anchor.image}}\" style=\"width:8rem; height: 8rem;\" /></th>
                    </tr>
                    <tr>
                        <th><p5>{{ anchor.reference }}</p5></th>
                    </tr>
                </table></td>
                <td><table>
                    <tr>
                        <th>{{ anchor.descriptif }}</th>
                    </tr>
                    <tr>
                        
                        <th> {{ anchor.createdAt | date('d / m / Y , H : m') }}<th>
                        
                    </tr>
                    
                </table></td>
                <td>{{ anchor.prix }} €</td>
                <td><table>
                    <tr>
                        <span class=\"title5 countdown \">
                                <div id=\"affiche\">Temps avant fin des enchères.</div>
                                    <script type=\"text/javascript\">
                                        var finTemps = produit.dateFin ; // < ?php echo \$donnees['finEnchere']; ? >
                                        var timestampActuel = <?php echo time(); ?>; // donne le timestamp actuel
                                        var duree = finTemps - timestampActuel; // durée = temps total - temps actuel
                                        var dureeHeure, dureeMinute, dureeSeconde; // initialise variable, pour qu'elles ne soient pas global
                                        var div = document.getElementById(\"affiche\"); // récupère la div affiche
                                
                                        // fait un interval régulier de 1s
                                        var timer = setInterval(function(){
                                                                
                                        // boucle tant que la durée est supérieur à 0
                                            if(duree>0)
                                            {
                                                dureeHeure = parseInt(duree/3600);
                                                dureeMinute = parseInt((duree-(dureeHeure*3600))/60);
                                                dureeSeconde = duree-((dureeHeure*3600)+(dureeMinute*60));
                                                var old_contenu = div.firstChild; // récup le premier enfant (le texte)
                                                div.removeChild(old_contenu); // supprime l'ancien contenu
                                                var texte = document.createTextNode(dureeHeure+\":\"+dureeMinute+\":\"+dureeSeconde); // crée un node texte valeur de la durée
                                                div.appendChild(texte); // affiche le node
                                                
                                                duree -= 1; // diminue la durée de l'enchère
                                            }
                                            // si l'enchère est finis
                                            else
                                            {
                                                var old_contenu = div.firstChild;
                                                div.removeChild(old_contenu); // supprime le contenu
                                                var texte = document.createTextNode('Enchère finis !'); // affiche message de fin, voir une alert
                                                div.appendChild(texte);
                                                clearInterval(timer); // interrompt la boucle de setInterval
                                            }
                                    }, 1000); // 1000ms
                                </script>                        
                        </span>
                    </tr>  
                    <tr>
                        <th>
                        {% for produit in produits %}
                            {{ produit.dateFin | date('d / m / Y , H : m') }}
                        {% endfor %}
                        </th>
                    </tr>   
                </table></td>
                    
                {% if app.user %}
                <td><table>
                    <tr>
                        <td><input class=\"form-control\" id=\"inputEncheres\" placeholder=\"Placez votre enchére\" label=\"prix\" style=\"width:150px\"></td>
                            {% block javascript %}
                                <script type=\"text/javascript\">
                                    function readInput(){
                                        //console.log(\"bonsoir\");   //test function 
                                        var encheres = new Array();
                                        var saisie= document.getElementById('inputEncheres').value;
                                        var inputs= encheres.push(saisie); // stocker toutes les inputs dans encheres (fait)
                                    }
                                    
                                
                                </script>
                            {% endblock %}
                        <td><button type=\"submit\" onclick=\"readInput();\"class=\"btn btn-secondary\">enchérir</button>
                        </td>
                    </tr></table>
                    <table>
                    <tr>
                        <td><input class=\"form-control\" id=\"inputDefault\" placeholder=\"de\" style=\"width:70px\"></td>
                        <td><input class=\"form-control\" id=\"inputDefault\" placeholder=\"à\"  style=\"width:70px\"></td>
                        <td><button type=\"submit\" class=\"btn btn-secondary\">enchérir</button></td>
                    </tr>
                </table></td>
                {% else %}
                    <td><a type=\"submit\" class=\"btn btn-secondary\" href=\"/inscription\">inscrivez vous pour enchérir</a></td>
                {% endif %}
        </tr>            
    {% endfor %}
    </tbody>
</table>    
{% endblock %}
", "home/anchors.html.twig", "C:\\Users\\33603\\Desktop\\web\\test\\templates\\home\\anchors.html.twig");
    }
}
